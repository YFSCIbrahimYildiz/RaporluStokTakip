<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
session_start();

if (!isset($_SESSION['kullanici_id']) || !yetkiVarMi($_SESSION['rol_id'], 'raporlar_excel.php')) {
    exit('Yetkiniz yok!');
}


header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=kritik_stoklar_" . date('Ymd_His') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "<table border='1'>";
echo "<tr>
        <th>#</th>
        <th>Malzeme Adı</th>
        <th>Tip</th>
        <th>Birim</th>
        <th>KDV Oranı (%)</th>
        <th>Mevcut Stok</th>
        <th>Min. Stok Limiti</th>
        <th>Açıklama</th>
      </tr>";

$sql = "
    SELECT 
        m.ad, 
        t.tip_adi, 
        m.birim,
        k.oran AS kdv_orani,
        m.mevcut_stok,
        m.min_stok_limiti,
        m.aciklama
    FROM malzemeler m
    LEFT JOIN malzeme_tipleri t ON m.tip_id = t.id
    LEFT JOIN kdv_oranlari k ON m.kdv_id = k.id
    WHERE m.mevcut_stok < m.min_stok_limiti
    ORDER BY m.ad
";

$sorgu = $db->query($sql);

$i = 1;
foreach ($sorgu as $row) {
    echo "<tr>";
    echo "<td>{$i}</td>";
    echo "<td>" . htmlspecialchars($row['ad']) . "</td>";
    echo "<td>" . htmlspecialchars($row['tip_adi']) . "</td>";
    echo "<td>" . htmlspecialchars($row['birim']) . "</td>";
    echo "<td>" . htmlspecialchars($row['kdv_orani']) . "</td>";
    echo "<td>" . htmlspecialchars($row['mevcut_stok']) . "</td>";
    echo "<td>" . htmlspecialchars($row['min_stok_limiti']) . "</td>";
    echo "<td>" . htmlspecialchars($row['aciklama']) . "</td>";
    echo "</tr>";
    $i++;
}

echo "</table>";
exit;
?>
